<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class ProductTime extends Model
{
    /**
     * todo
     * product_costを取得
     */
    public function product_cost()
    {
        //
    }

    /**
     * todo
     * 従業員を取得
     */
    public function employee()
    {
        //
    }
}
