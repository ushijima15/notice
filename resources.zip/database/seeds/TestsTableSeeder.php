<?php

use Illuminate\Database\Seeder;
use App\Test;

class TestsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //$model = new Test;$model->text="送信";$model->save();
    }
}
