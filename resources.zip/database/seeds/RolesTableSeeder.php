<?php

use Illuminate\Database\Seeder;
use App\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $model = new Role;$model->name = '工場長';$model->save();
        // $model = new Role;$model->name = 'リーダー';$model->save();
        // $model = new Role;$model->name = '担当';$model->save();
    }
}
